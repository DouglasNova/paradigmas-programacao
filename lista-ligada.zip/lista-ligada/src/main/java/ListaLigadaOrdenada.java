public class ListaLigadaOrdenada extends ListaLigada{

    @Override
    public void insereNode(Integer valor) {
        Node ant;
        Node atual;
    }

    @Override
    public Node buscaNode(Integer valor) {
        return super.buscaNode(valor);
    }

    @Override
    public boolean removeNode(Integer valor) {
        return super.removeNode(valor);
    }
}
